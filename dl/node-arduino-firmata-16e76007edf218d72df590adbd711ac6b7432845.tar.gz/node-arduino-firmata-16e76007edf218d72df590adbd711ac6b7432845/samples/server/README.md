Server Sample
=============

display arduino sensor value via socket.io

## Install Dependencies

    % npm install


## Start Server

    % node server.js

=> http://localhost:3000

