# Sysex Command Samples

Sysex
-----
- http://firmata.org/wiki/V2.1ProtocolDetails#Sysex_Message_Format
